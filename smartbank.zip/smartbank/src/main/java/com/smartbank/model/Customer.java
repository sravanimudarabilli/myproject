package com.smartbank.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.*;
@Entity
@Table(name="Customer")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	  @Column(name="id")
int id;
	@Column(name="custId")
long custId;
	@Column(name="firstName")
String firstName;
	@Column(name="lastName")
String lastName;
	@Column(name="age")
int age;
	@Column(name="gender")
String gender;
	@Column(name="city")
String city;
	@Column(name="occupy")
String occupy;
	@Column(name="pno")
String pno;
	@Column(name="accNo")
long accNo;
	@Column(name="email")
String email;
	@Column(name="type")
String type;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		//Random r=new Random();
		//custId=(long)(r.nextInt(8888888)+9999999);
		this.custId = custId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getOccupy() {
		return occupy;
	}
	public void setOccupy(String occupy) {
		this.occupy = occupy;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		//Random ran=new Random();
		//accNo=(long)(ran.nextInt(9999999)+999999999);
		this.accNo = accNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
