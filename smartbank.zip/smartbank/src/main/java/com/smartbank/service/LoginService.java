package com.smartbank.service;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.dao.LoginDao;
import com.smartbank.model.*;

public class LoginService {
	@Autowired
	private LoginDao loginDAO;
 

public boolean checkLogin(Login userBean) {
	return loginDAO.checkLogin(userBean);
}
		 
		

public void addUser(Customer Bean) {
	  loginDAO.addUser(Bean);  
	
}


		public boolean verifyId(Customer mBean) {
			// TODO Auto-generated method stub
		return	loginDAO.verifyId(mBean);
		}
}
