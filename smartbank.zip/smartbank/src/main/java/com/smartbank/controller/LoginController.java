package com.smartbank.controller;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.smartbank.model.*;
import com.smartbank.service.LoginService;
@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	@RequestMapping(value="/logout")
	public String out() {
	
		return "login";
	}	

@RequestMapping(value="/create")
	public String redirect() {
	
		return "customerPage";
	}
@RequestMapping(value="/clear")
public String clear() {

	return "customerPage";
}
@RequestMapping(value="/modify")
public String modify() {
//loginService.verifyId(mBean);
	return "Modify";
}
@RequestMapping(value="/recreate")
public String modified(@Valid @ModelAttribute("mBean")Customer mBean,BindingResult result,Model m) {
	boolean v=loginService.verifyId(mBean);
	if(v) {
	//System.out.println("u  "+mBean);
	//System.out.println(pass);   
	
	 return "modifyPage";
	}else {
		return "Modify";
	}
	
}

@RequestMapping(value="/direct", method = RequestMethod.POST)
public ModelAndView add(@Valid @ModelAttribute("Bean")Customer Bean,BindingResult result,Model m) {
	loginService.addUser(Bean);
	ModelAndView obj=new ModelAndView();
	obj.setViewName("success");
	obj.addObject("num", Bean);
	
return obj;	
}


	@RequestMapping(value="/doCheck", method = RequestMethod.POST)
	public String saveLogin(@Valid @ModelAttribute("userBean")Login userBean,BindingResult result,Model m)
	{
		if (result.hasErrors())
		{

			return "login";
		}
		else
		{
			String a;
			m.addAttribute("user", userBean);
			//String user=userBean.getUserName();
			String pass=userBean.getPassword();
			boolean p=loginService.checkLogin(userBean);
			if(p) {
			System.out.println("u  "+userBean);
			System.out.println(pass);         
			 return "welcome";
			}else {
				return "login";
			}
		}
		
		}
	}

