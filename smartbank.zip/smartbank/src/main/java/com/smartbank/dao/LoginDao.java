package com.smartbank.dao;
import org.hibernate.query.Query;

import java.util.Iterator;
import java.util.List;
import java.util.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.smartbank.model.*;
public class LoginDao {
	@Autowired
	private	 SessionFactory sessionFactory;

	public void addUser(Customer Bean) {

		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		Random ran=new Random();
		long acc=(long)(ran.nextInt(9999999)+999999999);
		long acid=(long)(ran.nextInt(99999)+9999999);		  
		Bean.setAccNo(acc);
		Bean.setCustId(acid);
		session.save(Bean);
		tx.commit();
		session.close(); 

	}

	public boolean checkLogin(Login userBean) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		boolean loginFound=false;
		String query="  from Login ";
		Query q=session.createQuery(query);
		//String user=userBean.getUserName();
		//q.setParameter(1, user);
		List<Login> list=q.getResultList();
		for (Iterator<Login> itr=list.iterator();itr.hasNext();)
		{

			for(Login u:list) {
				Login obj=(Login)itr.next();
				String u2=obj.getUserName();
				String u1=obj.getPassword();
				System.out.println(u1+u2);
				if((u2.equals(userBean.getUserName())) && (u1.equals(userBean.getPassword()))) {

					loginFound=true;
				}
			}	
		}
		session.close();
		return loginFound;

	}
	public boolean verifyId(Customer mBean) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		boolean found=false;
		String query="  from Customer ";
		Query q=session.createQuery(query);
		//String user=userBean.getUserName();
		//q.setParameter(1, user);
		List<Customer> list=q.getResultList();
		for (Iterator<Customer> itr=list.iterator();itr.hasNext();)
		{

			for(Customer u:list) {
				Customer obj=(Customer)itr.next();
				long u2=obj.getCustId();


				if(u2==mBean.getCustId()) {

					found=true;
				}
			}	
		}
		session.close();
		return found;

	}
}

